<?php
header('Content-Type: text/plain; charset=utf-8');
if (!is_dir('/data/local') || !is_writable('/data/local')) {
    http_response_code(503);
    echo 'Data storage unavailable';
    exit;
}
echo 'ok';
