<?php
// Compatibility additions for this separate private test copy, 2026-10-14.
// Original WAP-MOTOR author notices remain in the source files.
if (!function_exists('each')) {
    function each(&$array) {
        $key = key($array);
        if ($key === null) return false;
        $value = current($array);
        next($array);
        return array(1 => $value, 'value' => $value, 0 => $key, 'key' => $key);
    }
}
if (!function_exists('set_magic_quotes_runtime')) {
    function set_magic_quotes_runtime($enabled) { return false; }
}
if (!defined('SID')) define('SID', '');
$_SERVER['REMOTE_ADDR'] = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] = $_SERVER['HTTP_USER_AGENT'] ?? 'Motor test';
