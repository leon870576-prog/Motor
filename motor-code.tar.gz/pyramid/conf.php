<?php
#####################################
##     *** WAP MOTOR ****          ##
##      Автор : VERTUOZ            ##
##     E-mail : info@05dag.ru    ##
##       Site : http://05dag.ru  ##
##        ICQ : 369902212          ##
#####################################
// The optional module may have no configuration until its first admin save.
$pyramidConfig = BASEDIR.'pyramid/config.dat';
$pyramidValues = is_file($pyramidConfig) ? explode('|', trim(file_get_contents($pyramidConfig))) : [];
$look_ip = ($pyramidValues[0] ?? 'Off') === 'On' ? 'On' : 'Off';
$small_msg = ($pyramidValues[1] ?? 'Off') === 'On' ? 'On' : 'Off';
$msg_list = max(1, (int)($pyramidValues[2] ?? 5));
$all_msg = max(1, (int)($pyramidValues[3] ?? 100));
$msg_his = max(1, (int)($pyramidValues[4] ?? 10));
