<?php
// Shared guard for the legacy message forms that previously had no CSRF check.
function motor_form_token() {
    echo '<input type="hidden" name="uid" value="'.htmlspecialchars($_SESSION['token'], ENT_QUOTES, 'UTF-8').'" />';
}

function motor_form_guard(array $fields = ['msg']) {
    $token = $_POST['uid'] ?? '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !is_string($token) ||
        empty($_SESSION['token']) || !hash_equals($_SESSION['token'], $token)) {
        http_response_code(403);
        echo '<p>Отправка отклонена. Обновите форму и повторите действие.</p>';
        exit;
    }
    foreach ($fields as $field) {
        if (!isset($_POST[$field]) || !is_string($_POST[$field])) {
            http_response_code(400);
            echo '<p>Поле сообщения должно содержать текст.</p>';
            exit;
        }
    }
}
