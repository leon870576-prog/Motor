<?php
// Lesika themes, adapted for WAP-MOTOR 21 on 2026-10-15.
function lesika_themes(): array {
    static $themes;
    if ($themes === null) $themes = json_decode(file_get_contents(__DIR__.'/themes.json'), true, 512, JSON_THROW_ON_ERROR);
    return $themes;
}
function lesika_theme_id($id): string {
    if (is_string($id) && isset(lesika_themes()[$id])) return $id;
    return $id === 'night_city' ? 'lesika_vecher' : 'lesika_dvor';
}
function lesika_escape($text): string {
    return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function lesika_theme_options($selected, bool $disabledOption = false): string {
    $disabled = $disabledOption && ($selected === '' || (string)$selected === '0');
    $selected = $disabled ? '0' : lesika_theme_id($selected);
    $html = $disabledOption ? '<option value="0"'.($disabled ? ' selected' : '').'>Как на телефоне</option>' : '';
    foreach (lesika_themes() as $id => $theme) {
        $html .= '<option value="'.$id.'"'.($id === $selected ? ' selected' : '').'>'.lesika_escape($theme['name']).'</option>';
    }
    return $html;
}
function lesika_icon(string $name): string {
    $paths = [
        'home' => '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
        'news' => '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h3m3 0h2M8 18h8"/>',
        'forum' => '<path d="M21 11a8 8 0 0 1-8 8H7l-4 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 8h8M8 12h5"/>',
        'guest' => '<path d="M12 21s-9-5-9-12a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 7-9 12-9 12Z"/>',
        'theme' => '<path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-3 1.5 1.5 0 0 1 1-2h2a4 4 0 0 0 4-4 9 9 0 0 0-9-9Z"/><circle cx="7.5" cy="10" r=".7"/><circle cx="10" cy="6.5" r=".7"/><circle cx="15" cy="7" r=".7"/>',
        'user' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="9" r="3"/><path d="M6 19v-2a6 6 0 0 1 12 0v2"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'arrow' => '<path d="m9 5 7 7-7 7"/>',
        'image' => '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1"/><path d="m3 17 5-5 4 4 4-6 5 7"/>',
        'pin' => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
    ];
    return '<svg class="l-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$name] ?? $paths['arrow']).'</svg>';
}
