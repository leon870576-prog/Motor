<?php
#-----------------------------------------------------#
#          ********* WAP-MOTORS *********             #
#             Made by   :  VANTUZ                     #
#               E-mail  :  visavi.net@mail.ru         #
#                 Site  :  http://pizdec.ru           #
#             WAP-Site  :  http://visavi.net          #
#                  ICQ  :  36-44-66                   #
#  Вы не имеете право вносить изменения в код скрипта #
#        для его дальнейшего распространения          #
#-----------------------------------------------------#	
if (!defined('BASEDIR')) { http_response_code(403); exit; }
require_once BASEDIR.'includes/lesika/catalog.php';
if ($config['autoskins'] > 0) {
    echo '<form action="'.BASEDIR.'pages/skin.php" method="post"><label for="quick-theme">Оформление</label>';
    echo '<input type="hidden" name="uid" value="'.lesika_escape($_SESSION['token']).'">';
    echo '<select id="quick-theme" name="skins">'.lesika_theme_options($config['themes']).'</select>';
    echo '<input type="submit" value="Применить"></form>';
}
