<?php
#-----------------------------------------------------#
#          ********* WAP-MOTORS *********             #
#              Made by  :  VANTUZ                     #
#               E-mail  :  visavi.net@mail.ru         #
#                 Site  :  http://pizdec.ru           #
#             WAP-Site  :  http://visavi.net          #
#                  ICQ  :  36-44-66                   #
#  Вы не имеете право вносить изменения в код скрипта #
#        для его дальнейшего распространения          #
#-----------------------------------------------------#	
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/gallery.php';
if (!motor_gallery_moderator()) {http_response_code(403);exit('Недостаточно прав.');}
include '../themes/'.$config['themes'].'/index.php';
show_title('gallery.gif','Управление фотографиями');
echo '<nav class="gallery-actions"><a href="gallery.php">Все фото</a><a href="gallery.php?filter=hidden">Скрытые</a><a href="../gallery/index.php">Открыть галерею</a>';
if (motor_gallery_admin()) echo '<a href="gallery-settings.php">Настройки галереи</a>';
echo '</nav>';
try {
    motor_gallery_request_guard();
    $action=$_GET['action'] ?? '';
    if (!is_string($action)) throw new RuntimeException('Некорректный запрос.',400);
    if (in_array($action,['addedit','batch'],true)) {motor_form_guard([]);motor_gallery_lock();}
    $rows=motor_gallery_rows();
    if ($action==='addedit') {
        $gid=$_POST['gid'] ?? '';$photo=motor_gallery_find($gid,$rows);
        if (!$photo) throw new RuntimeException('Фото удалено или не существует.',404);
        motor_gallery_check_version($photo['row']);[$name,$msg]=motor_gallery_input();
        $d=$photo['data'];$d[0]=$msg;$d[1]=no_br($name);$rows[$photo['index']]=implode('|',$d);
        motor_gallery_save($rows);motor_gallery_audit('edit',[$gid]);
        header('Location: gallery.php?action=edit&gid='.$gid.'&saved=1');exit;
    }
    if ($action==='batch') {
        motor_gallery_check_version(implode("\n",$rows));
        $ids=$_POST['photos'] ?? [];$command=$_POST['command'] ?? '';
        if (!is_array($ids) || !$ids || count($ids)>24 || !in_array($command,['hide','restore','delete'],true)) throw new RuntimeException('Выберите фотографии и действие.',400);
        $selected=[];
        foreach ($ids as $id) {
            $photo=motor_gallery_find($id,$rows);
            if (!$photo) throw new RuntimeException('Выбранное фото не найдено. Обновите список.',409);
            $selected[$id]=$photo;
        }
        if ($command==='delete' && ($_POST['confirm_delete'] ?? '')!=='1') throw new RuntimeException('Подтвердите безвозвратное удаление фотографий и их комментариев.',400);
        foreach ($selected as $id=>$photo) {
            if ($command==='delete') unset($rows[$photo['index']]);
            else {$d=$photo['data'];$d[3]=$command==='hide'?'hidden':'';$rows[$photo['index']]=implode('|',$d);}
        }
        motor_gallery_save($rows);
        if ($command==='delete') foreach ($selected as $id=>$photo) {
            motor_gallery_remove_files($id);
            $author=$photo['data'][2];
            if (preg_match('/^[a-z0-9_-]+$/Di',$author) && is_file(DATADIR.'profil/'.$author.'.prof')) {
                $profile=explode(':||:',file_get_contents(DATADIR.'profil/'.$author.'.prof'));
                if (($profile[72] ?? '')===$id) change_profil($author,[72=>'']);
            }
        }
        motor_gallery_audit($command,array_keys($selected));
        header('Location: gallery.php?done='.count($selected));exit;
    }
    if ($action==='edit') {
        $gid=$_GET['gid'] ?? null;
        // Read compatibility for bookmarks from the old panel; writes always use a stable ID.
        if ($gid===null && isset($_GET['id']) && is_string($_GET['id']) && ctype_digit($_GET['id']) && isset($rows[(int)$_GET['id']])) $gid=explode('|',$rows[(int)$_GET['id']])[6] ?? '';
        $photo=motor_gallery_find($gid,$rows);
        if (!$photo) throw new RuntimeException('Фотография не найдена.',404);
        if (isset($_GET['saved'])) echo '<p role="status">Название и подпись сохранены.</p>';
        motor_gallery_card($photo,true);
        echo '<form method="post" action="gallery.php?action=addedit">';motor_form_token();motor_gallery_version($photo['row']);
        echo '<input type="hidden" name="gid" value="'.$gid.'"><label>Название<input name="name" required maxlength="100" value="'.motor_gallery_escape(motor_gallery_plain($photo['data'][1])).'"></label><label>Подпись<textarea name="msg" rows="4" maxlength="2000" data-smile-picker data-smile-scope="common">'.motor_gallery_escape(motor_gallery_plain($photo['data'][0])).'</textarea></label><button type="submit" class="primary">Сохранить изменения</button></form>';
        motor_gallery_batch_form_start($rows);
        echo '<input type="hidden" name="photos[]" value="'.$gid.'">';motor_gallery_batch_controls();echo '</form>';
    } elseif ($action==='') {
        if (isset($_GET['done'])) echo '<p role="status">Действие выполнено. Фотографий: '.(int)$_GET['done'].'.</p>';
        $filter=($_GET['filter'] ?? '')==='hidden'?'hidden':'';$photos=[];
        foreach (array_reverse($rows,true) as $i=>$row) {
            $d=explode('|',$row);
            if (motor_gallery_valid_id($d[6] ?? null) && (!$filter || ($d[3] ?? '')==='hidden')) $photos[]=['index'=>$i,'row'=>$row,'data'=>$d];
        }
        $page=motor_gallery_settings()['per_page'];$total=count($photos);$start=max(0,(int)($_GET['start'] ?? 0));if ($start>=$total) $start=0;
        if ($total) {
            motor_gallery_batch_form_start($rows);echo '<div class="gallery-grid">';
            foreach (array_slice($photos,$start,$page) as $photo) {
                echo '<section><label class="gallery-select"><input type="checkbox" name="photos[]" value="'.$photo['data'][6].'"> Выбрать фото</label>';motor_gallery_card($photo);echo '</section>';
            }
            echo '</div>';motor_gallery_batch_controls();echo '</form>';
            page_jumpnavigation('gallery.php?filter='.$filter.'&amp;',$page,$start,$total);page_strnavigation('gallery.php?filter='.$filter.'&amp;',$page,$start,$total);
        } else echo '<p>Фотографий в этом списке нет.</p>';
        $auditPath=DATADIR.'datagallery/gallery-audit.jsonl';
        if (is_file($auditPath)) {
            $labels=['edit'=>'Изменена подпись','hide'=>'Скрыто','restore'=>'Возвращено','delete'=>'Удалено','delete_comments'=>'Удалены комментарии','settings'=>'Изменены настройки'];
            echo '<details class="gallery-audit"><summary>Последние действия администрации</summary><ol>';
            foreach (array_reverse(array_slice(file($auditPath,FILE_IGNORE_NEW_LINES),-20)) as $line) {
                $entry=json_decode($line,true);if (!is_array($entry)) continue;
                echo '<li>'.motor_gallery_escape(date_fixed((int)$entry['time']).' · '.$entry['actor'].' · '.($labels[$entry['action']] ?? $entry['action']).' · '.implode(', ',$entry['photos'])).'</li>';
            }
            echo '</ol></details>';
        }
    } else throw new RuntimeException('Страница не найдена.',404);
} catch (Throwable $e) {motor_gallery_error($e);}
echo '<p><a href="index.php">В админку</a></p>';
include '../themes/'.$config['themes'].'/foot.php';
