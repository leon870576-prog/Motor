<?php
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/attachments.php';
if (!is_admin([101,102])) { http_response_code(403); exit('Доступ разрешён только администраторам.'); }
include '../themes/'.$config['themes'].'/index.php';
motor_media_request_guard();
show_title('files.gif', 'Настройки вложений');
echo '<p><a href="gallery-settings.php">Фото в галерее: размеры, форматы, увеличение</a></p>';
$settings = motor_media_settings(); $types = motor_media_types();
$groups = ['photo'=>'Фото', 'video'=>'Видео', 'file'=>'Файлы'];
$sections = ['forum'=>'Форум', 'news'=>'Новости'];
$cap = motor_media_cap(); $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!motor_media_csrf()) motor_media_stop('Неверный идентификатор сессии. Обновите страницу.', 403);
    try {
        $new = [];
        foreach ($sections as $section=>$title) {
            $input = $_POST[$section] ?? [];
            if (!is_array($input)) throw new RuntimeException('Неверные настройки раздела.');
            foreach (['count'=>[0,10], 'photo_mb'=>[1,$cap], 'video_mb'=>[1,$cap], 'file_mb'=>[1,$cap], 'image_px'=>[320,12000], 'preview_px'=>[240,1200]] as $key=>$bounds) {
                $v = filter_var($input[$key] ?? null, FILTER_VALIDATE_INT);
                if ($v === false || $v < $bounds[0] || $v > $bounds[1]) throw new RuntimeException($title.': поле «'.$key.'» должно быть от '.$bounds[0].' до '.$bounds[1].'.');
                $new[$section][$key] = $v;
            }
            $formats = $input['formats'] ?? [];
            if (!is_array($formats) || count(array_filter($formats, 'is_string')) !== count($formats) || array_diff($formats, array_keys($types))) throw new RuntimeException('Выбран неподдерживаемый формат.');
            $new[$section]['formats'] = array_values(array_unique($formats));
        }
        motor_media_atomic(DATADIR.'attachment-settings.json', json_encode($new, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        $settings = $new;
        echo '<p class="theme-success" role="status">Настройки сохранены. Они применяются к новым загрузкам; существующие вложения сохранены.</p>';
    } catch (Throwable $e) { http_response_code(400); $error = $e->getMessage(); }
}
if ($error) show_error(motor_media_escape($error));
echo '<p>Отдельные ограничения для каждого раздела. Количество — суммарно на одну запись. Ноль отключает новые вложения.</p>';
echo '<p>Лимит сервера: '.$cap.' МБ на файл, '.motor_media_escape(ini_get('post_max_size')).' на одну отправку. Изображения — не более 40 мегапикселей.</p>';
echo '<form method="post"><input type="hidden" name="uid" value="'.motor_media_escape($_SESSION['token']).'" />';
foreach ($sections as $section=>$title) {
    $s = $settings[$section]; echo '<fieldset><legend>'.$title.'</legend>';
    foreach (['count'=>['Вложений на запись',0,10], 'photo_mb'=>['Максимальный вес фото, МБ',1,$cap], 'video_mb'=>['Максимальный вес видео, МБ',1,$cap], 'file_mb'=>['Максимальный вес файла, МБ',1,$cap], 'image_px'=>['Максимальная сторона фото, px',320,12000], 'preview_px'=>['Максимальная ширина показа, px',240,1200]] as $key=>$field) {
        echo '<label>'.$field[0].'<input required type="number" name="'.$section.'['.$key.']" value="'.(int)$s[$key].'" min="'.$field[1].'" max="'.$field[2].'" step="1" /></label>';
    }
    foreach ($groups as $kind=>$label) {
        echo '<fieldset class="attachment-formats"><legend>'.$label.': разрешённые форматы</legend>';
        foreach ($types as $ext=>$type) if ($type[0] === $kind) echo '<label><input type="checkbox" name="'.$section.'[formats][]" value="'.$ext.'"'.(in_array($ext, $s['formats'], true) ? ' checked' : '').' /> '.strtoupper($ext).'</label> ';
        echo '</fieldset>';
    }
    echo '</fieldset>';
}
echo '<p>Размер показа автоматически уменьшается до ширины экрана. Видео: MP4 или WebM; воспроизведение зависит от кодека устройства, скачивание доступно всегда.</p><input type="submit" value="Сохранить настройки" /></form><p><a href="index.php">В админку</a></p>';
include '../themes/'.$config['themes'].'/foot.php';
