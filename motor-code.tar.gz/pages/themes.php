<?php
#-----------------------------------------------------#
#          ********* WAP-MOTORS *********             #
#             Made by   :  VANTUZ                     #
#               E-mail  :  visavi.net@mail.ru         #
#                 Site  :  http://pizdec.ru           #
#             WAP-Site  :  http://visavi.net          #
#                  ICQ  :  36-44-66                   #
#  Вы не имеете право вносить изменения в код скрипта #
#        для его дальнейшего распространения          #
#-----------------------------------------------------#	
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
$config['newtitle'] = 'Оформление';
include '../themes/'.$config['themes'].'/index.php';
show_title('themes.gif', 'Ваш уютный стиль');
echo '<p class="theme-intro">Семь тёплых тем «Лесики». Выберите настроение для своего города.</p>';
if (isset($_GET['saved']) && $_GET['saved'] === '1') echo '<p class="theme-success" role="status">Оформление сохранено.</p>';
echo '<div class="theme-grid">';
foreach (lesika_themes() as $id => $theme) {
    $selected = $id === $config['themes'];
    echo '<form action="skin.php" method="post"><input type="hidden" name="skins" value="'.$id.'">';
    echo '<input type="hidden" name="uid" value="'.lesika_escape($_SESSION['token']).'"><input type="hidden" name="return" value="themes">';
    echo '<button class="theme-card" type="submit" data-theme="'.$id.'" aria-pressed="'.($selected ? 'true' : 'false').'" aria-label="Выбрать: '.lesika_escape($theme['name']).'">';
    echo '<span class="theme-preview" aria-hidden="true"><span class="preview-brand"></span><span class="preview-welcome"></span><span class="preview-row"></span><span class="preview-row"></span></span>';
    echo '<span class="theme-name">'.lesika_escape($theme['name']).($selected ? lesika_icon('check') : '').'</span><span class="theme-description">'.lesika_escape($theme['description']).'</span></button></form>';
}
echo '</div><p class="theme-back"><a href="../index.php">← Вернуться на главную</a></p>';
include '../themes/'.$config['themes'].'/foot.php';
