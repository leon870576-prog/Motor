<?php
#-----------------------------------------------------#
#          ********* WAP-MOTORS *********             #
#             Made by   :  VANTUZ                     #
#               E-mail  :  visavi.net@mail.ru         #
#                 Site  :  http://pizdec.ru           #
#             WAP-Site  :  http://visavi.net          #
#                  ICQ  :  36-44-66                   #
#  Вы не имеете право вносить изменения в код скрипта #
#        для его дальнейшего распространения          #
#-----------------------------------------------------#	
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
$config['newtitle'] = 'Оформление';
include '../themes/'.$config['themes'].'/index.php';
show_title('themes.gif', 'Ваш уютный стиль');
echo '<p class="theme-intro">Семь компактных и пять широких веб-тем. Все подстраиваются под экран телефона. Выберите свой уютный стиль.</p>';
if (isset($_GET['saved']) && $_GET['saved'] === '1') echo '<p class="theme-success" role="status">Оформление сохранено.</p>';
foreach (['compact'=>'Для телефона', 'web'=>'Для компьютера и планшета'] as $layout => $heading) {
echo '<section class="theme-group"><h2>'.lesika_escape($heading).'</h2><div class="theme-grid">';
foreach (lesika_themes() as $id => $theme) {
    if (($theme['layout'] ?? 'compact') !== $layout) continue;
    $selected = $id === $config['themes'];
    echo '<form action="skin.php" method="post"><input type="hidden" name="skins" value="'.$id.'">';
    echo '<input type="hidden" name="uid" value="'.lesika_escape($_SESSION['token']).'"><input type="hidden" name="return" value="themes">';
    echo '<button class="theme-card" type="submit" data-theme="'.$id.'" aria-pressed="'.($selected ? 'true' : 'false').'" aria-label="Выбрать: '.lesika_escape($theme['name']).'">';
    echo '<span class="theme-preview'.($layout === 'web' ? ' theme-preview-web' : '').'" aria-hidden="true"><span class="preview-brand"></span><span class="preview-welcome"></span><span class="preview-row"></span><span class="preview-row"></span><span class="preview-columns"><i></i><i></i><i></i></span></span>';
    echo '<span class="theme-name">'.lesika_escape($theme['name']).($selected ? lesika_icon('check') : '').'</span><span class="theme-description">'.lesika_escape($theme['description']).'</span></button></form>';
}
echo '</div></section>';
}
echo '<p class="theme-back"><a href="../index.php">← Вернуться на главную</a></p>';
include '../themes/'.$config['themes'].'/foot.php';
