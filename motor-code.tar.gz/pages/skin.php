<?php
#-----------------------------------------------------#
#          ********* WAP-MOTORS *********             #
#             Made by   :  VANTUZ                     #
#               E-mail  :  visavi.net@mail.ru         #
#                 Site  :  http://pizdec.ru           #
#             WAP-Site  :  http://visavi.net          #
#                  ICQ  :  36-44-66                   #
#  Вы не имеете право вносить изменения в код скрипта #
#        для его дальнейшего распространения          #
#-----------------------------------------------------#	
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
$action = isset($_GET['action']) && is_string($_GET['action']) ? $_GET['action'] : '';
if ($action === 'navigation') {
    $link = isset($_POST['link']) && is_string($_POST['link']) ? check($_POST['link']) : 'index.php';
    header('Location: '.BASEDIR.verifi($link));
    exit;
}
$posted = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$skin = $_POST['skins'] ?? $_GET['skins'] ?? '';
$valid = is_string($skin) && isset(lesika_themes()[$skin]);
$tokenValid = !$posted || (isset($_POST['uid']) && is_string($_POST['uid']) && hash_equals((string)$_SESSION['token'], $_POST['uid']));
if ($valid && $tokenValid) {
    $_SESSION['my_themes'] = $skin;
    setcookie('lesika_theme', $skin, ['expires'=>time()+31536000, 'path'=>'/', 'secure'=>true, 'httponly'=>true, 'samesite'=>'Lax']);
    if ($posted && is_user()) change_profil($log, array(20=>$skin));
    $next = isset($_POST['return']) && $_POST['return'] === 'themes' ? 'pages/themes.php?saved=1' : 'index.php';
    header('Location: '.BASEDIR.$next, true, 303);
    exit;
}
http_response_code($tokenValid ? 400 : 403);
include '../themes/'.$config['themes'].'/index.php';
show_error($tokenValid ? 'Выберите одну из доступных тем «Лесики».' : 'Обновите страницу и выберите тему ещё раз.');
echo '<a href="themes.php">Вернуться к выбору оформления</a>';
include '../themes/'.$config['themes'].'/foot.php';
