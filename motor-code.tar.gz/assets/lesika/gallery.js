/* Local photo viewer. No uploads, persistence, analytics, or automatic form submission. */
(() => {
 'use strict';
 if(!document.querySelector('[data-gallery-zoom]') || typeof HTMLDialogElement==='undefined')return;
 const viewer=document.createElement('dialog');viewer.className='gallery-viewer';viewer.setAttribute('aria-label','Просмотр фотографии с увеличением');
 const toolbar=document.createElement('div');toolbar.className='gallery-toolbar';
 function button(label,text,fn){
  const b=document.createElement('button');b.type='button';b.setAttribute('aria-label',label);b.textContent=text;
  let press=null,suppressClickUntil=0;
  // A mobile browser may suppress its synthetic click immediately after a pan.
  // Handle a short, primary touch release directly, without firing twice on click.
  b.addEventListener('pointerdown',e=>{if(e.isPrimary&&e.pointerType!=='mouse')press={id:e.pointerId,x:e.clientX,y:e.clientY};});
  b.addEventListener('pointermove',e=>{if(press&&Math.hypot(e.clientX-press.x,e.clientY-press.y)>12)press=null;});
  b.addEventListener('pointercancel',()=>{press=null;});
  b.addEventListener('pointerup',e=>{
   const valid=press&&press.id===e.pointerId;press=null;if(!valid||b.disabled)return;
   const r=b.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;
   e.preventDefault();suppressClickUntil=performance.now()+600;fn();
  });
  b.addEventListener('click',e=>{if(e.detail!==0&&performance.now()<suppressClickUntil){e.preventDefault();return;}fn();});
  toolbar.append(b);return b;
 }
 const stage=document.createElement('div');stage.className='gallery-stage';stage.tabIndex=0;stage.setAttribute('aria-label','Фотография. Раздвиньте пальцы для увеличения, перетаскивайте для перемещения');
 const picture=document.createElement('img');picture.draggable=false;picture.hidden=true;stage.append(picture);
 const loading=document.createElement('p');loading.className='gallery-loading';loading.setAttribute('role','status');stage.append(loading);
 const hint=document.createElement('p');hint.className='gallery-viewer-hint';hint.textContent='Раздвиньте пальцы или нажмите +. Двойное нажатие увеличивает. Стрелки перемещают фото, Esc закрывает.';
 let scale=1,x=0,y=0,fitW=0,fitH=0,ready=false,trigger=null,previousOverflow='',tap=null,gesture=false;
 const pointers=new Map();
 const minus=button('Уменьшить','−',()=>setScale(scale/1.4));
 const plus=button('Увеличить','+',()=>setScale(scale*1.4));
 button('Показать целиком','Целиком',()=>{x=y=0;setScale(1);});
 const status=document.createElement('output');status.className='gallery-scale';status.setAttribute('aria-label','Масштаб относительно экрана');toolbar.append(status);
 const close=button('Закрыть просмотр','×',()=>viewer.close());close.className='gallery-close';
 viewer.append(toolbar,stage,hint);document.body.append(viewer);
 function paint(){
  const rect=stage.getBoundingClientRect();
  x=Math.max(-Math.max(0,(fitW*scale-rect.width)/2),Math.min(Math.max(0,(fitW*scale-rect.width)/2),x));
  y=Math.max(-Math.max(0,(fitH*scale-rect.height)/2),Math.min(Math.max(0,(fitH*scale-rect.height)/2),y));
  picture.style.transform=`translate(${x}px,${y}px) scale(${scale})`;status.textContent=Math.round(scale*100)+'%';
  minus.disabled=!ready||scale<=1;plus.disabled=!ready||scale>=5;
 }
 function setScale(value,anchorX=0,anchorY=0){
  if(!ready)return;
  const next=Math.max(1,Math.min(5,value)),ratio=next/scale;
  x=anchorX-(anchorX-x)*ratio;y=anchorY-(anchorY-y)*ratio;scale=next;paint();
 }
 function fit(){
  if(!ready)return;
  const rect=stage.getBoundingClientRect(),ratio=Math.min(rect.width/picture.naturalWidth,rect.height/picture.naturalHeight,1);
  fitW=picture.naturalWidth*ratio;fitH=picture.naturalHeight*ratio;
  Object.assign(picture.style,{width:fitW+'px',height:fitH+'px',marginLeft:-fitW/2+'px',marginTop:-fitH/2+'px'});paint();
 }
 picture.addEventListener('load',()=>{if(!viewer.open)return;ready=true;loading.hidden=true;picture.hidden=false;fit();});
 picture.addEventListener('error',()=>{ready=false;picture.hidden=true;loading.hidden=false;loading.textContent='Не удалось открыть фото. Возможно, оно скрыто или удалено. Закройте просмотр и обновите страницу.';paint();});
 document.addEventListener('click',event=>{
  const link=event.target.closest('a[data-gallery-zoom]');if(!link||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  let url;try{url=new URL(link.href,location.href);}catch{return;}
  if(url.origin!==location.origin||!url.pathname.endsWith('/gallery/fullsize.php')||!/^[-\w][\w.-]*\.(jpe?g|png|gif|webp)$/i.test(url.searchParams.get('name')||''))return;
  event.preventDefault();trigger=link;ready=false;scale=1;x=y=0;tap=null;pointers.clear();
  picture.hidden=true;picture.alt=link.querySelector('img')?.alt||'Фотография';loading.hidden=false;loading.textContent='Открываем оригинал…';
  previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';viewer.showModal();paint();picture.src=url.href;close.focus();
 });
 viewer.addEventListener('close',()=>{document.body.style.overflow=previousOverflow;ready=false;pointers.clear();picture.removeAttribute('src');picture.hidden=true;trigger?.focus({preventScroll:true});});
 function point(event){const r=stage.getBoundingClientRect();return {x:event.clientX-r.left-r.width/2,y:event.clientY-r.top-r.height/2};}
 function pair(){const p=[...pointers.values()];return p.length<2?null:{x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2,d:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y)};}
 stage.addEventListener('pointerdown',event=>{
  if(!ready||event.button>0)return;
  pointers.set(event.pointerId,{...point(event),origin:point(event)});stage.setPointerCapture(event.pointerId);
  if(pointers.size>1){gesture=true;tap=null;}else gesture=false;
 });
 stage.addEventListener('pointermove',event=>{
  const old=pointers.get(event.pointerId);if(!old)return;
  const before=pair(),next={...point(event),origin:old.origin};pointers.set(event.pointerId,next);
  if(Math.hypot(next.x-old.origin.x,next.y-old.origin.y)>8)gesture=true;
  const after=pair();
  if(before&&after&&before.d>2){setScale(scale*after.d/before.d,before.x,before.y);x+=after.x-before.x;y+=after.y-before.y;paint();}
  else if(scale>1){x+=next.x-old.x;y+=next.y-old.y;paint();}
 });
 function release(event){
  if(!pointers.has(event.pointerId))return;
  const p=point(event);pointers.delete(event.pointerId);
  if(event.type==='pointerup'&&!gesture&&!pointers.size){
   const now=performance.now();if(tap&&now-tap.time<320&&Math.hypot(p.x-tap.x,p.y-tap.y)<28){setScale(scale>1?1:2.5,p.x,p.y);tap=null;}else tap={...p,time:now};
  }
  if(event.type!=='pointerup'){tap=null;gesture=true;}
 }
 for(const name of ['pointerup','pointercancel','lostpointercapture'])stage.addEventListener(name,release);
 stage.addEventListener('wheel',event=>{if(!ready)return;event.preventDefault();const p=point(event);setScale(scale*(event.deltaY<0?1.15:1/1.15),p.x,p.y);},{passive:false});
 viewer.addEventListener('keydown',event=>{
  if(event.key==='Tab'){
   const items=[...viewer.querySelectorAll('button:not(:disabled),[tabindex="0"]')].filter(el=>el.getClientRects().length);
   const first=items[0],last=items.at(-1),active=document.activeElement;
   if(event.shiftKey&&(active===first||!viewer.contains(active))){event.preventDefault();last?.focus();}
   else if(!event.shiftKey&&(active===last||!viewer.contains(active))){event.preventDefault();first?.focus();}
   return;
  }
  if(event.key==='+'||event.key==='='){event.preventDefault();setScale(scale*1.4);}
  else if(event.key==='-'){event.preventDefault();setScale(scale/1.4);}
  else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){event.preventDefault();x+=event.key==='ArrowLeft'?48:event.key==='ArrowRight'?-48:0;y+=event.key==='ArrowUp'?48:event.key==='ArrowDown'?-48:0;paint();}
 });
 new ResizeObserver(fit).observe(stage);
})();
