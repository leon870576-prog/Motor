<?php
require_once __DIR__.'/includes/start.php';
require_once __DIR__.'/includes/functions.php';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/attachments.php';
// Keep the engine's login, site closure and ban checks, then switch to binary output.
while (ob_get_level()) ob_end_clean();
header_remove('Content-Encoding');
ini_set('zlib.output_compression', '0');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-cache');
header("Content-Security-Policy: default-src 'none'; sandbox");
if (!in_array($_SERVER['REQUEST_METHOD'], ['GET','HEAD'], true)) { http_response_code(405); header('Allow: GET, HEAD'); exit; }
$section = $_GET['section'] ?? '';
$parent = $_GET['parent'] ?? '';
$id = $_GET['file'] ?? '';
if (!motor_media_valid_parent($section, $parent) || !preg_match('/^[a-f0-9]{32}$/D', $id)) { http_response_code(404); exit; }
$manifest = motor_media_manifest($section, $parent);
$exists = false;
if ($section === 'news') {
    $exists = (bool)search_string(DATADIR.'news.dat', $parent, 5);
} else {
    $fid = (int)($manifest['context']['fid'] ?? 0); $topic = (int)($manifest['context']['topic'] ?? 0);
    $path = DATADIR.'dataforum/'.$fid.'-'.$topic.'.dat';
    if (is_file($path) && is_file(DATADIR.'dataforum/topic'.$fid.'.dat') && search_string(DATADIR.'dataforum/mainforum.dat', $fid, 0) && search_string(DATADIR.'dataforum/topic'.$fid.'.dat', $topic, 0)) {
        foreach (file($path) as $line) { $data = explode('|', $line); if (trim($data[6] ?? '') === $parent) { $exists = true; break; } }
    }
}
$file = null;
foreach ($manifest['files'] as $candidate) if ($candidate['id'] === $id) { $file = $candidate; break; }
$path = motor_media_dir($section, $parent).'/'.$id.'.blob';
if (!$exists || !$file || !is_file($path)) { http_response_code(404); exit; }
$stream = @fopen($path, 'rb');
if (!$stream) { http_response_code(404); exit; }
$size = fstat($stream)['size']; $start = 0; $end = $size - 1;
session_write_close();
header('Accept-Ranges: bytes');
if (isset($_SERVER['HTTP_RANGE'])) {
    $valid = preg_match('/^bytes=(\d*)-(\d*)$/D', trim($_SERVER['HTTP_RANGE']), $range);
    if ($valid && ($range[1] !== '' || $range[2] !== '')) {
        if ($range[1] === '') { $length = (int)$range[2]; $start = max(0, $size - $length); if ($length < 1) $valid = false; }
        else { $start = (int)$range[1]; if ($range[2] !== '') $end = min($end, (int)$range[2]); }
        if ($start > $end || $start >= $size) $valid = false;
    } else $valid = false;
    if (!$valid) { http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
    http_response_code(206); header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
}
$inline = $file['kind'] !== 'file' && empty($_GET['download']);
header('Content-Type: '.$file['mime']);
header('Content-Disposition: '.($inline ? 'inline' : 'attachment').'; filename="attachment.'.$file['ext'].'"; filename*=UTF-8\'\''.rawurlencode($file['name']));
header('Content-Length: '.($end - $start + 1));
if ($_SERVER['REQUEST_METHOD'] === 'HEAD') exit;
fseek($stream, $start); $remaining = $end - $start + 1;
while ($remaining > 0 && !feof($stream) && !connection_aborted()) {
    $chunk = fread($stream, min(65536, $remaining)); if ($chunk === false || $chunk === '') break;
    echo $chunk; $remaining -= strlen($chunk);
}
fclose($stream);
