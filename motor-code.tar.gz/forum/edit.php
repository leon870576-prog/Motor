<?php
require_once '../includes/start.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/attachments.php';
include '../themes/'.$config['themes'].'/index.php';
motor_media_request_guard();
$fid = abs((int)($_GET['fid'] ?? 0)); $id = abs((int)($_GET['id'] ?? 0)); $post = abs((int)($_GET['post'] ?? 0));
$path = DATADIR.'dataforum/'.$fid.'-'.$id.'.dat';
$forum = search_string(DATADIR.'dataforum/mainforum.dat', $fid, 0);
$topic = is_file(DATADIR.'dataforum/topic'.$fid.'.dat') ? search_string(DATADIR.'dataforum/topic'.$fid.'.dat', $id, 0) : false;
$lines = is_file($path) ? file($path) : [];
if (!$forum || !$topic || !isset($lines[$post])) motor_media_stop('Сообщение не найдено.', 404);
$data = explode('|', $lines[$post]);
if (!is_user() || (!is_admin() && ($data[2] !== $log || !empty($topic[6])))) motor_media_stop('Нет прав на редактирование этого сообщения.', 403);
show_title('edit.gif', 'Редактирование сообщения');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!motor_media_csrf()) motor_media_stop('Неверный идентификатор сессии.', 403);
    motor_media_check_version($lines[$post]);
    $msg = check($_POST['msg'] ?? '');
    if (utf_strlen(trim($msg)) < 5 || utf_strlen($msg) > 5000) motor_media_stop('Сообщение должно содержать от 5 до 5000 символов.');
    $data[3] = smiles(antimat(no_br($msg, '<br />')));
    $media_id = trim($data[6] ?? '') ?: motor_media_uuid();
    $text = implode('|', array_slice($data, 0, 6)).'|'.$media_id.'|';
    motor_media_save_record('forum', $media_id, ['fid'=>$fid,'topic'=>$id], $path, $post, $text);
    $_SESSION['note'] = 'Сообщение и вложения обновлены!';
    redirect('topic.php?fid='.$fid.'&id='.$id.'&start='.(int)(floor($post/$config['forumpost'])*$config['forumpost']));
}
$text = html_entity_decode(str_replace('<br />', "\n", nosmiles($data[3])), ENT_QUOTES | ENT_HTML5, 'UTF-8');
echo '<form method="post" enctype="multipart/form-data"><input type="hidden" name="uid" value="'.motor_media_escape($_SESSION['token']).'" />';
motor_media_version($lines[$post]);
echo '<label>Сообщение<textarea name="msg" rows="8" required minlength="5" maxlength="5000">'.motor_media_escape($text).'</textarea></label>';
motor_media_render('forum', trim($data[6] ?? ''));
motor_media_form('forum', trim($data[6] ?? ''));
echo '<input type="submit" value="Сохранить изменения" /></form><p><a href="topic.php?fid='.$fid.'&amp;id='.$id.'">Вернуться в тему</a></p>';
include '../themes/'.$config['themes'].'/foot.php';
