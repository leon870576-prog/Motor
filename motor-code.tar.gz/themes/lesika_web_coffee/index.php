<?php
// Adaptive Lesika web theme.
require BASEDIR.'includes/lesika/head.php';
