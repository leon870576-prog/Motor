<?php
// Lesika palette: Городская гостиная. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
