<?php
// Lesika palette: Солнечный город. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
