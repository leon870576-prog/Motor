<?php
// Lesika palette: Соседский альбом. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
