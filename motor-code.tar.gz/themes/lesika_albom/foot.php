<?php
require BASEDIR.'includes/lesika/foot.php';
