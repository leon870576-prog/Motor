<?php
// Lesika palette: Тёплый двор. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
