<?php
// Lesika palette: Вечерний уют. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
