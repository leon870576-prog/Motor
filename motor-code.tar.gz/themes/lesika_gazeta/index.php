<?php
// Lesika palette: Городская газета. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
