<?php
// Lesika palette: Современный уют. Shared adaptive template.
require BASEDIR.'includes/lesika/head.php';
